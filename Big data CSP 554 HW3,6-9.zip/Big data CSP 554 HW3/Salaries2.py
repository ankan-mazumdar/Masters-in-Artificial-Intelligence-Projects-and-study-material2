from mrjob.job import MRJob

class MRWorkerSalaries(MRJob):

    def configure_args(self):
        super(MRWorkerSalaries, self).configure_args()
        self.add_passthru_arg('--salary-thresholds', default='100000,50000',
                              help='Comma-separated salary thresholds for High, Medium, and Low')

    def mapper(self, _, line):
        (name, jobTitle, agencyID, agency, hireDate, annualSalary, grossPay) = line.split('\t')
        annual_salary = float(annualSalary)

        salary_thresholds = [float(threshold) for threshold in self.options.salary_thresholds.split(',')]
        if annual_salary >= salary_thresholds[0]:
            yield 'High', 1
        elif annual_salary >= salary_thresholds[1]:
            yield 'Medium', 1
        else:
            yield 'Low', 1

    def combiner(self, salary_category, counts):
        yield salary_category, sum(counts)

    def reducer(self, salary_category, counts):
        yield salary_category, sum(counts)


if __name__ == '__main__':
    MRWorkerSalaries.run()
