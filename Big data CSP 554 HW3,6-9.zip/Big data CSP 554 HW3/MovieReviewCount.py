from mrjob.job import MRJob

class MRUserMovieCount(MRJob):

    def configure_args(self):
        super(MRUserMovieCount, self).configure_args()
        self.add_passthru_arg('--input-file', default='u.data',
                              help='Input CSV file with user reviews')

    def mapper(self, _, line):
        # Split the CSV line into user_id and movie_id
        user_id, movie_id, rating, timestamp = line.split(',')

        # Emit the user_id as the key and a count of 1 as the value
        yield user_id, 1

    def reducer(self, user_id, review_counts):
        # Sum the counts to get the total number of movies reviewed by the user
        total_reviews = sum(review_counts)

        # Emit the user_id and the total number of reviews
        yield user_id, total_reviews

if __name__ == '__main__':
    MRUserMovieCount.run()
