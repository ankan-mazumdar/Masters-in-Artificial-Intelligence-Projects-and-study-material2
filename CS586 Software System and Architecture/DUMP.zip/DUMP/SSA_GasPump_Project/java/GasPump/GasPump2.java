package GasPump;

import AbstractFactory.AbstractFactory;
import Model.EFSM.MDAEFSM;
import Model.OutputProcessor.OutputProcessor;
import PlatformData.DS;
import PlatformData.DS2;

/*
    This class is the InputProcessor for GasPump2
 */
public class GasPump2 {
    DS data;
    MDAEFSM model;
    public GasPump2(AbstractFactory af) {
        this.data = af.getDataObj();
        this.model = new MDAEFSM();
        this.model.setOP(new OutputProcessor(af));
    }
    /*
        Prints a menu of supported operations in GasPump2
     */
    public void printOperations() {
        System.out.println(
                        "*********************************************************************" +
						 "\nGasPump-2 " +
                        "\nSelect operation: " +
                        "\n(0) Activate(float a, float b, float c)" +
                        "\n(1) Start " +
                        "\n(2) PayCash " +
                        "\n(3) Regular " +
                        "\n(4) Premium " +
                        "\n(5) Diesel " +
                        "\n(6) Cancel " +
                        "\n(7) StartPump " +
                        "\n(8) PumpGallon " +
                        "\n(9) Stop " +
                        "\n(p) PrintReceipt " +
                        "\n(n) NoReceipt " +
                        "\n(q) Quit the program " +
                        "\n*********************************************************************"
        );
    }

    /*
        Check the input parameters for correctness, and call the
        activate() meta-event of the EFSM model

        If input is incorrect, print a message indicating as such

        @param a: price of Regular gas
        @param b: price of Super gas
        @param c: price of Premium gas
     */
    public void Activate(float a, float b, float c) {
        if (a > 0 && b > 0 && c > 0) {
            DS2 d = (DS2) data;
            d.Set_temp_a(a);
            d.Set_temp_b(b);
            d.Set_temp_c(c);
            model.activate();
        } else {
            System.out.println("Activation failed!");
            System.out.println("Prices must be greater than $0");
        }
    }

    /*
        Call the start() meta-event of the EFSM model
     */
    public void Start() {
        model.start();
    }
    
    /*
        Calls the PayCash() meta-event of the EFSM model

        Sets the PayType to 0
     */
    public void PayCash(int cash) {
        if (cash > 0) {
            DS2 d = (DS2) data;
            d.Set_temp_cash(cash);
            model.payType(0);
        } else {
            System.out.println("Cash amount must be greater than $0");
        }
    }

    /*
        Call the cancel() meta-event of the EFSM model
     */
    public void Cancel() {
        model.cancel();
    }

    /*
        Call the selectGas() meta-event of the EFSM model,
        passing in 1 as the gas-type for Regular Gas
     */
    public void Regular() {
        model.selectGas(1);
        model.Continue();
    }

    /*
        Call the selectGas() meta-event of the EFSM model,
        passing in 2 as the gas-type for Premium Gas
     */
    public void Premium() {
        model.selectGas(2);
        model.Continue();
    }
    
    /*
        Call the selectGas() meta-event of the EFSM model,
        passing in 3 as the gas-type for Diesel Gas
     */
    public void Diesel() {
        model.selectGas(3);
        model.Continue();
    }

    /*
        Call the startPump() meta-event of the EFSM model
     */
    public void StartPump() {
        System.out.println("Please start Pumping ");
        model.startPump();
    }

    /*
        First, check the shared data structure for remaining amount of cash
        If there is not enough cash to pump another liter, print a message indicating as such,
        and call the stopPump() meta-event of the EFSM model

        Otherwise, call the pump() meta-event of the EFSM model
     */
    public void PumpGallon() {
        DS2 d = (DS2) data;
        if (d.Get_cash() < d.Get_price() * (d.Get_G() + 1)) {
            System.out.println("NOT ENOUGH CASH");
            model.stopPump();
        } else {
            model.pump();
        }
    }

    /*
        Call the stopPump() meta-event of the EFSM model
     */
    public void Stop() {
        model.stopPump();
    }

    /*
        Call the receipt() meta-event of the EFSM model
     */
    public void Receipt() {
        model.receipt();  
        RefreshGP2();  
    }

    /*
        Call the noReceipt() meta-event of the EFSM model
     */
    public void NoReceipt() {
        model.noReceipt();
        RefreshGP2();
    }
    
    /*
    Refreshes the DataStore for GasPump2
     */
    public void RefreshGP2(){
        DS2 d = (DS2) data;
        d.Set_price(0);
        d.Set_total(0);
        d.Set_cash(0);
        d.Set_w(0);
        d.Set_G(0);
    }
    
    /*
     This method is not required. However, this method can be called to check the current state and
     the status of diffent Data transactions.
     */
    public void check(){
        DS2 d = (DS2) data;
        System.out.println("temp_a = "+d.Get_temp_a());
        System.out.println("temp_b = "+d.Get_temp_b());
        System.out.println("temp_c = "+d.Get_temp_c());
        System.out.println("reg = "+d.Get_Rprice());
        System.out.println("prem = "+d.Get_Pprice());
        System.out.println("dis = "+d.Get_Dprice());
        System.out.println("temp_cash = "+d.Get_temp_cash());
        System.out.println("price = "+d.Get_price());
        System.out.println("total = "+d.Get_total());
        System.out.println("Cash = "+d.Get_cash());
        System.out.println("w = "+d.Get_w());
        System.out.println("G = "+d.Get_G());
        System.out.println("State = "+model.CheckState());
    }
}
