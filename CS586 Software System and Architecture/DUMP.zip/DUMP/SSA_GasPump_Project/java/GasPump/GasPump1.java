package GasPump;

import AbstractFactory.AbstractFactory;
import Model.EFSM.MDAEFSM;
import Model.OutputProcessor.OutputProcessor;
import PlatformData.DS;
import PlatformData.DS1;

/*
    GasPump1 class - present the operations for Gas Pump 1
 */
public class GasPump1 {
    DS data;
    MDAEFSM model;

    public GasPump1(AbstractFactory af) {
        this.data = af.getDataObj();
        this.model = new MDAEFSM();
        this.model.setOP(new OutputProcessor(af));
    }

    /*
        Prints a menu of supported operations in GasPump1
     */
    public void printOperations() {
        System.out.println(
                        "*********" +
						"\n GasPump-1 " +                        
                        "\nSelect operation: " +
                        "\n(0) Activate(int a) " +
                        "\n(1) Start " +
                        "\n(2) PayCredit " +
                        "\n(3) Approve " +
                        "\n(4) Reject" +
                        "\n(5) PayCash " +
                        "\n(6) Cancel " +
                        "\n(7) StartPump " +
                        "\n(8) Pump " +
                        "\n(9) StopPump " +
                        "\n{q} Quit the program " +
                        "\n*********"
        );
    }

    /*
        Calls meta-event activate().
        Activates GasPump1. This method sets the price of gas to the input argument. 
        Tempoarily the value is stored in a temp_a variable.
        If activation amount i.e. the input argument is less than 0, it shows an error message.
     */
    public void Activate(int a) {
        if (a > 0) {
            DS1 d = (DS1) this.data;
            d.Set_temp_a(a);
            model.activate();
        } else {
            System.out.println("Activation failed!");
            System.out.println("Prices must be greater than $0");
        }
    }

    /*
        Call the start() meta-event of the EFSM model
     */
    public void Start() {
        model.start();
    }

    /*
        Call the payType() meta-event of the EFSM model,
        passing "1" as the payment type which represents credit payment

        Also print a credit card authentication message
     */
    public void PayCredit() {
        model.payType(1);
        System.out.println("AUTHENTICATING CREDIT CARD, please select (3) to Approve or (4) to Reject");
    }

    /*
        Calls the approve() meta-event of the EFSM model
     */
    public void Approve() {
        model.approve();
    }

    /*
        Calls the reject() meta-event of the EFSM model
     */
    public void Reject() {
        model.reject();
    }

    /*
        Calls the cancel() meta-event of the EFSM model
     */
    public void Cancel() {
        model.cancel();
    }
    
    /*
        Calls the PayCash() meta-event of the EFSM model

        Sets the PayType to 0
     */
    public void PayCash(int c) {
        DS1 d = (DS1) this.data;
        d.Set_temp_cash(c);
        model.payType(0);
    }

    /*
        Call the startPump() meta-event of the EFSM model

        Changes state from S3 to S4 and calls StartPump()
     */
    public void StartPump() {
        model.Continue();
        model.startPump();
		System.out.println("Please select Pump to dispense");
    }

    /*
        Call the pump() meta-event of the EFSM model

        If paytype is by credit it pumps 1 litre of gas.
        If pay type is cash, it checks if suffient cash is there.
        If so, it pumps 1 litre of gas otherwise stops pump and returns remaining cash.
     */
    public void Pump() {
        
        DS1 d = (DS1) data;
        if(d.Get_w() == 1)
        {
            model.pump(); 
        }
        else
        {
            if (d.Get_cash() < d.Get_price() * (d.Get_L() + 1)) {
                System.out.println("NOT ENOUGH CASH");
                model.stopPump();
                model.receipt();
                RefreshGP1();
            } else {
                model.pump();
            }
        }
    }

    /*
        call the stopPump() and receipt() meta-events of the EFSM model

        GasPump1 always prints receipts after fuel is finished dispensing under current
        system design.
        
        Refreshes GasPump1 when it moves from S6 to S0
     */
    public void StopPump() {
        model.stopPump();
        model.receipt();
        RefreshGP1();
    }
    
    /*
    Refreshes the DataStore for GasPump1
     */
    public void RefreshGP1(){
        DS1 d = (DS1) data;
        d.Set_total(0);
        d.Set_cash(0);
        d.Set_w(0);
        d.Set_L(0);
    }
    
    /*
     This method is not required. However, this method can be called to check the current state and
     the status of diffent Data transactions.
     */
    public void check(){
        DS1 d = (DS1) data;
        System.out.println("temp_a = "+d.Get_temp_a());
        System.out.println("temp_cash = "+d.Get_temp_cash());
        System.out.println("price = "+d.Get_price());
        System.out.println("total = "+d.Get_total());
        System.out.println("Cash = "+d.Get_cash());
        System.out.println("w = "+d.Get_w());
        System.out.println("L = "+d.Get_L());
        System.out.println("State = "+model.CheckState());
    }
}
