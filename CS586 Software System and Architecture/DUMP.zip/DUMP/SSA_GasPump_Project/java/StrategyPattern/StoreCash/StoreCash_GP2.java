package StrategyPattern.StoreCash;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of StoreCash() for GasPump2
 */
public class StoreCash_GP2 extends StoreCash {

    public StoreCash_GP2(DS data) {
        super(data);
    }

    @Override
    public void storeCash() {
        DS2 d = (DS2) data;
        d.Set_cash(d.Get_temp_cash());
        System.out.println("Amount of cash inserted: $" + d.Get_cash());
    }
}
