package StrategyPattern.StoreCash;

import PlatformData.DS;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for StoreCash action. Method StoreCash() will be implemented in GP1 and GP2 separately.
 */
public abstract class StoreCash {
    DS data;

    public StoreCash(DS  data) {
        this.data = data;
    }

    public abstract void storeCash();
}
