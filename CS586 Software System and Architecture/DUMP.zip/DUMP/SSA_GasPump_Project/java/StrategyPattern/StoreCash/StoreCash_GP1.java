package StrategyPattern.StoreCash;

/*
        Strategy Pattern    *
    Implementation of storeCash() for GasPump1
 */

 import PlatformData.DS;
import PlatformData.DS1;

public class StoreCash_GP1 extends StoreCash {

    public StoreCash_GP1(DS data) {
        super(data);
    }

    @Override
    public void storeCash() {
        DS1 d = (DS1) data;
        d.Set_cash(d.Get_temp_cash());
        System.out.println("Amount of cash inserted: $" + d.Get_cash());
    }
}
