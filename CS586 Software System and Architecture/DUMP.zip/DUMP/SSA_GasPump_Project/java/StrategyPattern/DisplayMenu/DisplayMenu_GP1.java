package StrategyPattern.DisplayMenu;

import PlatformData.DS;

/*
    **********    Strategy Pattern    ***********
    Implementation of displayMenu() for GasPump1
 */
public class DisplayMenu_GP1 extends DisplayMenu {

    public DisplayMenu_GP1(DS data) {
        super(data);
    }

    @Override
    public void displayMenu() {
        //Displays the menu
        System.out.println("card is approved.Please select (7) to StartPump or (6) to Cancel");
    }
}
