package StrategyPattern.DisplayMenu;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of displayMenu() for GasPump2
 */


public class DisplayMenu_GP2 extends DisplayMenu {

    public DisplayMenu_GP2(DS data) {
        super(data);
    }

    
    @Override
    public void displayMenu() {
        DS2 d = (DS2) data;
        System.out.println("Please select gas type: ");
        System.out.println(
                "(3) Regular [$" + d.Get_Rprice() + "/gallon] " +
                        "\n(4) Premium [$" + d.Get_Pprice() + "/gallon] " +
                        "\n(5) Diesel [$" + d.Get_Dprice() + "/gallon]");
        System.out.println("Otherwise, select (6) to cancel");

        //Displays the menu
        System.out.println("Below is the Gas Pump Menu:");
    }
}
