package StrategyPattern.DisplayMenu;

import PlatformData.DS;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for DisplayMenu action. Method DisplayMenu() will be implemented in GP1 and GP2 separately.
 */
public abstract class DisplayMenu {
    DS data;

    public DisplayMenu(DS data) {
        this.data = data;
    }

    public abstract void displayMenu();

}
