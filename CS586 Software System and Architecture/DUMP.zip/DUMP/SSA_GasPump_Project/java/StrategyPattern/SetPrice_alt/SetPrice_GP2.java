package StrategyPattern.SetPrice_alt;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of SetPrice() for GasPump1
 */

public class SetPrice_GP2 extends SetPrice {

    public SetPrice_GP2(DS data) {
        super(data);
    }
    
    /*
    Users have 3 options - Regular, Premium and Diesel.
    Based on the selection, price of gas is set.
     */
    @Override
    public void setPrice(int gasType) {
        DS2 d = (DS2) data;
        String selectedGas = "";
        if (gasType == 1) { 
            d.Set_price(d.Get_Rprice());
            selectedGas = "regular";
        } else if (gasType == 2) { 
            d.Set_price(d.Get_Pprice());
            selectedGas = "Premium";
        } else if (gasType == 3) { 
            d.Set_price(d.Get_Dprice());
            selectedGas = "Diesel";
        }
        System.out.println(selectedGas + " gasoline selected @ price of $" + d.Get_price() + "/liter");
        System.out.println("Select (7) to start the pump");
    }
}
