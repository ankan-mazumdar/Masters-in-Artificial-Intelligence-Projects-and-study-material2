package StrategyPattern.SetPrice_alt;

import PlatformData.DS;

/*
    **********    Strategy Pattern    ***********
    Implementation of payMsg() for GasPump1
 */

public abstract class SetPrice {
    DS data;

    public SetPrice(DS data) {
        this.data = data;
    }

    public abstract void setPrice(int g);
}
