package StrategyPattern.SetPrice_alt;

import PlatformData.DS;

/*
    **********    Strategy Pattern    ***********
    Implementation of SetPrice() for GasPump1
 */

public class SetPrice_GP1 extends SetPrice {

    public SetPrice_GP1(DS data) {
        super(data);
    }
    
    /*
    blank implementation for Gas Pump 1, as it does not support selection of gas.
     */
    @Override
    public void setPrice(int gasType) {
        
    }
}
