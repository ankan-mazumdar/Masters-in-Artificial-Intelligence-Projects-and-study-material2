package StrategyPattern.EjectCard;

public class Ejectcard_GP1 extends Ejectcard{

    @Override
    public void ejectCard() {
        //Display eject card message
        System.out.println("Please remove your card.");
    }
}
