package StrategyPattern.EjectCard;

public class Ejectcard_GP2 extends Ejectcard{
    @Override
    public void ejectCard() {
        //blank implementation as not required in GasPump2
    }
}
