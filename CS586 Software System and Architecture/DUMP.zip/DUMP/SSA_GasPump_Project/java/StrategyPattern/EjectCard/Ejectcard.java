package StrategyPattern.EjectCard;

public abstract class Ejectcard {

    public abstract void ejectCard();
}
