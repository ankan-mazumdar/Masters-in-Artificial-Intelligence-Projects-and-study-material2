package StrategyPattern.SetInitialValues;

import PlatformData.DS;
import PlatformData.DS1;

/*
    **********    Strategy Pattern    ***********
    Implementation of SetInitialValues() for GasPump1
 */

public class SetInitialValues_GP1 extends SetInitialValues {

    public SetInitialValues_GP1(DS data) {
        super(data);
    }
    
    /*
    Sets L and total to 0
     */
    @Override
    public void setInitialValues() {
        DS1 d = (DS1) data;
        d.Set_L(0);
        d.Set_total(0);
    }
}
