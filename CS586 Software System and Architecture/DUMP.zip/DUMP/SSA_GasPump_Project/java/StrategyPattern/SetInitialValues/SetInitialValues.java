package StrategyPattern.SetInitialValues;

import PlatformData.DS;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for SetInitialValues action. Method SetInitialValues() will be implemented in GP1 and GP2 separately.
 */
public abstract class SetInitialValues {
    DS data;

    public SetInitialValues(DS data) {
        this.data = data;
    }

    public abstract void setInitialValues();
}
