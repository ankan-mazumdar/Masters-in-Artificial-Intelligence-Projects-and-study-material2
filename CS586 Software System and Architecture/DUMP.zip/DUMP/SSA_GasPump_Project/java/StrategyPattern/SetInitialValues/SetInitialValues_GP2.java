package StrategyPattern.SetInitialValues;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of payMsg() for GasPump2
 */
public class SetInitialValues_GP2 extends SetInitialValues {

    public SetInitialValues_GP2(DS data) {
        super(data);
    }

    /*
    Sets G and total to 0
     */
    @Override
    public void setInitialValues() {
        DS2 d = (DS2) data;
        d.Set_G(0);
        d.Set_total(0);
    }
}
