package StrategyPattern.PayMsg;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for PayMsg action. Method PayMsg() will be implemented in GP1 and GP2 separately.
 */
public abstract class PayMsg {
    public PayMsg() {
    }

    public abstract void payMsg();
}
