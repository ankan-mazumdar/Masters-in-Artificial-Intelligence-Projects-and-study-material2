package StrategyPattern.PayMsg;

/*
    **********    Strategy Pattern    ***********
    Implementation of payMsg() for GasPump1
 */
public class PayMsg_GP1 extends PayMsg {

    /*
        Print a payment selection prompt
     */
    @Override
    public void payMsg() {
        System.out.println("Thank you for choosing GasPump-1");
        System.out.println("Please select payment type");
    }
}
