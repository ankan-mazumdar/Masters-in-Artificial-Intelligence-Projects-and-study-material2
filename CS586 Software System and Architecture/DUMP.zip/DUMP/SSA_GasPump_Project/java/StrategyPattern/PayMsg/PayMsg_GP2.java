package StrategyPattern.PayMsg;

/*
    **********    Strategy Pattern    ***********
    Implementation of payMsg() for GasPump2
 */

public class PayMsg_GP2 extends PayMsg {

    @Override
    public void payMsg() {
        //User can only pay by cash
        System.out.println("Thank you for choosing GasPump-2");
        System.out.println("Please proceed with the payment: ");
    }
}
