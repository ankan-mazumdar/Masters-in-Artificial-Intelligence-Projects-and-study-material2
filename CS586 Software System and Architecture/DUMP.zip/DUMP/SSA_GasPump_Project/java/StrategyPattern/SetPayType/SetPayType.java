package StrategyPattern.SetPayType;

import PlatformData.DS;

public abstract class SetPayType {
    DS data;
    
    public SetPayType(DS data) {
        this.data = data;
    }

    public abstract void setPayType(int t);
}
