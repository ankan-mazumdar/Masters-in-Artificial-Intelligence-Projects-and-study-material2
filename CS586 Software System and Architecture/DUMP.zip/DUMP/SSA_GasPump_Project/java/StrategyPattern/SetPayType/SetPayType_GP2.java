package StrategyPattern.SetPayType;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of setPayType() for GasPump2
 */

public class SetPayType_GP2 extends SetPayType{
    public SetPayType_GP2(DS data) {
        super(data);
    }
    
    /*
    Allows only Cash payment. Sets pay type to 0.
     */
    @Override
    public void setPayType(int t) {
        DS2 d = (DS2) data;
        d.Set_w(t);
    }
}
