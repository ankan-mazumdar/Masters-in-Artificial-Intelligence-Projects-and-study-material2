package StrategyPattern.SetPayType;

import PlatformData.DS;
import PlatformData.DS1;

/*
    **********    Strategy Pattern    ***********
    Implementation of setPayType() for GasPump1
 */

public class SetPayType_GP1 extends SetPayType{
    public SetPayType_GP1(DS data) {
        super(data);
    }
    
    /*
    Sets PayType = 1 for credit card payment and 0 for cash payment
     */
    @Override
    public void setPayType(int t) {
        DS1 d = (DS1) data;
        d.Set_w(t);
    }
}
