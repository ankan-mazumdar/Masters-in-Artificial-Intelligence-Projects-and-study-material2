package StrategyPattern.StorePrices;

import PlatformData.DS;

/*
    Abstract StoreData action strategy
    Groups all "Store Data" actions under 1 abstract superclass
 */
public abstract class StoreData {
    DS data;

    public StoreData(DS data) {
        this.data = data;
    }

    public abstract void storeData();
}
