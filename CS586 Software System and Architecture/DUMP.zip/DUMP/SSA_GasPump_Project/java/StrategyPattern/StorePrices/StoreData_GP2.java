package StrategyPattern.StorePrices;

import PlatformData.DS;
import PlatformData.DS2;

/*
    GasPump2 StoreData action responsible for storing the "a", "b", and "c"  price parameters specified by
    method "Activate" of the InputProcessor for GasPump2
 */
public class StoreData_GP2 extends StoreData {

    public StoreData_GP2(DS data) {
        super(data);
    }

    /*
        Read the temporary variables "a", "b", and "c"  and initialize the gas prices of the system accordingly
     */
    @Override
    public void storeData() {
        DS2 d = (DS2) data;
        d.Set_Rprice(d.Get_temp_a());
        d.Set_Pprice(d.Get_temp_b());
        d.Set_Dprice(d.Get_temp_c());
        System.out.println("GasPump2 activated successfully!");
    }
}
