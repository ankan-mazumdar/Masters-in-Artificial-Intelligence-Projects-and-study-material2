package StrategyPattern.StorePrices;

import PlatformData.DS;
import PlatformData.DS1;

/*
    GasPump1 StoreData action responsible for storing the "a" price parameters specified by
    method "Activate" of the InputProcessor for GasPump1
 */
public class StoreData_GP1 extends StoreData {

    public StoreData_GP1(DS data) {
        super(data);
    }

    /*
        Read the temporary variables "a" and initialize the gas prices of the system accordingly
     */
    @Override
    public void storeData() {
        DS1 d = (DS1) data;
        d.Set_price(d.Get_temp_a());
        System.out.println("GasPump1 got activated successfully!");
    }
}
