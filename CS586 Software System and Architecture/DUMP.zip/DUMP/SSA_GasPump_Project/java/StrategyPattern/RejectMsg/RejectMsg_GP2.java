package StrategyPattern.RejectMsg;

/*
    GasPump1 RejectMsg action responsible for printing a credit card rejection message
 */
public class RejectMsg_GP2 extends RejectMsg {

    /*
        Blank implementation. Not required in GasPump2.
     */
    @Override
    public void rejectMsg() {
        
    }
}
