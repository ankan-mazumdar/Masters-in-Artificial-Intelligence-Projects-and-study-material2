package StrategyPattern.RejectMsg;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for RejectMsg action. Method RejectMsg() will be implemented in GP1. 
    GP2 does not allow paycredit, so this method is not implemented in GP2
 */

public abstract class RejectMsg {
    public RejectMsg() {
    }

    public abstract void rejectMsg();
}
