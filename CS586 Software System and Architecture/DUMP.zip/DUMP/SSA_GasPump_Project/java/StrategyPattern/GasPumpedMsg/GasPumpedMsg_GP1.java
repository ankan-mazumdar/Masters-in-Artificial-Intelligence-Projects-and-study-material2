package StrategyPattern.GasPumpedMsg;

import PlatformData.DS;
import PlatformData.DS1;

/*
    **********    Strategy Pattern    ***********
    Implementation of gasPumpedMsg() for GasPump1
 */
public class GasPumpedMsg_GP1 extends GasPumpedMsg {

    public GasPumpedMsg_GP1(DS data) {
        super(data);
    }

    @Override
    public void gasPumpedMsg() {
        DS1 d = (DS1) data;
        System.out.println("Pumped 1 litre of gas");
        System.out.println("Total # of litres pumped: " + d.Get_L());
    }

}
