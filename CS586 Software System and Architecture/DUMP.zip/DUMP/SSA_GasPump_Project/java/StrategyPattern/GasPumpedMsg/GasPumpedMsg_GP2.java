package StrategyPattern.GasPumpedMsg;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of gasPumpedMsg() for GasPump2
 */
public class GasPumpedMsg_GP2 extends GasPumpedMsg {

    public GasPumpedMsg_GP2(DS data) {
        super(data);
    }

    @Override
    public void gasPumpedMsg() {
        DS2 d = (DS2) data;
        System.out.println("Pumped 1 gallon of gasoline");
        System.out.println("Total # of gallons pumped: " + d.Get_G());
    }
}
