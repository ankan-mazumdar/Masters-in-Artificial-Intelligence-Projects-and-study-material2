package StrategyPattern.GasPumpedMsg;

import PlatformData.DS;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for GasPumpedMsg action. Method gasPumpedMsg() will be implemented in GP1 and GP2 separately.
 */
public abstract class GasPumpedMsg {
    DS data;
    public GasPumpedMsg(DS data) {
        this.data = data;
    }

    public abstract void gasPumpedMsg();
}
