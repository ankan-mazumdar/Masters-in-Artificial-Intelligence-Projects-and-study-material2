package StrategyPattern.PrintReceipt;

import PlatformData.DS;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for PrintReceipt action. Method PrintReceipt() will be implemented in GP1 and GP2 separately.
 */

public abstract class PrintReceipt {
    DS data;

    public PrintReceipt(DS data) {
        this.data = data;
    }

    public abstract void printReceipt();
}
