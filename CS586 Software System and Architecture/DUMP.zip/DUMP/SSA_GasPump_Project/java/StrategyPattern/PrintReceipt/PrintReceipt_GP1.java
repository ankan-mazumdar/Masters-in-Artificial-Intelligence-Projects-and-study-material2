package StrategyPattern.PrintReceipt;

import PlatformData.DS;
import PlatformData.DS1;

/*
    **********    Strategy Pattern    ***********
    Implementation of printReceipt() for GasPump1
 */
public class PrintReceipt_GP1 extends PrintReceipt {

    public PrintReceipt_GP1(DS data) {
        super(data);
    }

    @Override
    public void printReceipt() {
        System.out.println("Printing receipt ...");
        System.out.println("######################################################################");
        DS1 d = (DS1) data;
        System.out.println(d.Get_L() + " litres of gas in price " + d.Get_price() + "/litre");
        System.out.println("Total: $" + d.Get_total());
        System.out.println("#######################################################################");
        System.out.println("Transaction complete");
    }
}
