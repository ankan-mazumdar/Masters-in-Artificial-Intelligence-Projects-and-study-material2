package StrategyPattern.PrintReceipt;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of payMsg() for GasPump2
 */
public class PrintReceipt_GP2 extends PrintReceipt {

    public PrintReceipt_GP2(DS data) {
        super(data);
    }

    /*
        Print a receipt by reading the appropriate values form the shared data structure
     */
    @Override
    public void printReceipt() {
        System.out.println("Printing receipt ...");
        System.out.println("*********************************************************************");
        DS2 d = (DS2) data;
        System.out.println(d.Get_G() + " gallons of gasoline @ $ with price " + d.Get_price() + "/liter");
        System.out.println("Total: $" + (float) d.Get_total());
        System.out.println("Cash inserted: $" + d.Get_cash());
        System.out.println("*********************************************************************");
        System.out.println("Transaction complete");
    }
}
