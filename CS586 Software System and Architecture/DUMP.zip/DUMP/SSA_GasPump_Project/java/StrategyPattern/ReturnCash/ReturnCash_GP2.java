package StrategyPattern.ReturnCash;

import PlatformData.DS;
import PlatformData.DS2;

/*
    **********    Strategy Pattern    ***********
    Implementation of returnCash() for GasPump2
 */
public class ReturnCash_GP2 extends ReturnCash {

    public ReturnCash_GP2(DS data) {
        super(data);
    }

    
    @Override
    public void returnCash() {
        DS2 d = (DS2) data;
        float cash_return = d.Get_cash() - d.Get_total();
		String formattedCashReturn = String.format("%.2f", cash_return);
		//System.out.println("Formatted Cash Return: " + formattedCashReturn);
        if (cash_return > 0) {
            System.out.println("Cash returned: $" + formattedCashReturn);
           
        } else {
            System.out.println("Credit card used, hence No cash to return");
        }
        d.Set_cash(0);
        System.out.println("Transaction finished");
    }
}
