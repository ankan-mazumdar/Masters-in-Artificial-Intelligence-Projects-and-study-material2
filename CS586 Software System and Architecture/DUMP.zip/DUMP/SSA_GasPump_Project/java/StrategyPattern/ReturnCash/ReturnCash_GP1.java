package StrategyPattern.ReturnCash;

import PlatformData.DS;
import PlatformData.DS1;

/*
    **********    Strategy Pattern    ***********
    Implementation of returnCash() for GasPump1
 */
public class ReturnCash_GP1 extends ReturnCash {
    
    public ReturnCash_GP1(DS data) {
        super(data);
    }
    @Override
    public void returnCash() {
        DS1 d = (DS1) data;
        float cash_return = d.Get_cash() - d.Get_total();
        if (cash_return > 0) {
            System.out.println("Cash returned:  $" + cash_return);
            
        } else {
            System.out.println("No cash to return");
        }
        d.Set_cash(0);
        System.out.println("Transaction Done");
    }
}
