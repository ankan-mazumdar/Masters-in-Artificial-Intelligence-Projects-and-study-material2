package StrategyPattern.ReturnCash;

import PlatformData.DS;

/*
    Strategy Pattern 
    It is an abstract class for ReturnCash action. Method ReturnCash() will be implemented in GP1 and GP2 separately.
 */

public abstract class ReturnCash {
    DS data;

    
    public ReturnCash() {
    }
    
    //passing datastore DS to the constructor
    public ReturnCash(DS data) {
        this.data = data;
    }

    public abstract void returnCash();
}
