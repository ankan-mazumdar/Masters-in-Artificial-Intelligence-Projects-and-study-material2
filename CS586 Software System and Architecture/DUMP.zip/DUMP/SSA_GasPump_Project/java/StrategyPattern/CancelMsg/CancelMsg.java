package StrategyPattern.CancelMsg;
/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for CancelMsg.Method CancelMsg() will be implemented in GP1 and GP2 separately.
 */
public abstract class CancelMsg {
    public CancelMsg() {
    }

    public abstract void cancelMsg();
}
