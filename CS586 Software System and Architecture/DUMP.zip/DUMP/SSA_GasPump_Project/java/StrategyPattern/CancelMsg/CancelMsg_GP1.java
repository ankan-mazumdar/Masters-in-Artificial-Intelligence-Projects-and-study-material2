package StrategyPattern.CancelMsg;

/*
    **********    Strategy Pattern    ***********
    Implementation of cancelMsg() for GasPump1
 */
public class CancelMsg_GP1 extends CancelMsg {

    @Override
    public void cancelMsg() {
        //prints a cancellation message
        System.out.println("Cancelling transaction ... ");
    }
}
