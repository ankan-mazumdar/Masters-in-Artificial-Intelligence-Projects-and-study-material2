package StrategyPattern.CancelMsg;

/*
    **********    Strategy Pattern    ***********
    Implementation of cancelMsg() for GasPump2
 */
public class CancelMsg_GP2 extends CancelMsg {

    @Override
    public void cancelMsg() {
        //prints a cancellation message
        System.out.println("Cancelling transaction ... ");
    }
}
