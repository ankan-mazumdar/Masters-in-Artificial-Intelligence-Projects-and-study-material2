package StrategyPattern.PumpGasUnit_alt;

import PlatformData.DS;
import PlatformData.DS1;

/*
    ********************   Strategy Pattern   ****************** 
    It is an abstract class for pumpGasUnit action. Method pumpGasUnit() will be implemented in GP1 and GP2 separately.
 */

public class PumpGasUnit_GP1 extends PumpGasUnit {

    public PumpGasUnit_GP1(DS data) {
        super(data);
    }

    /*
        Read and update the appropriate data structure attributes that correspond to
        pumping a gallon of gas
     */
    @Override
    public void pumpGasUnit() {
        DS1 d = (DS1) data;
        /*
            Call the subroutine that ACTUALLY pumps gas here
            Now increment the appropriate data values
        */
        d.Set_L(d.Get_L()+1);
        d.Set_total(d.Get_price() * d.Get_L());
    }
}
