package StrategyPattern.PumpGasUnit_alt;

import PlatformData.DS;

public abstract class PumpGasUnit {
    DS data;

    public PumpGasUnit(DS data) {
        this.data = data;
    }

    public abstract void pumpGasUnit();
}
