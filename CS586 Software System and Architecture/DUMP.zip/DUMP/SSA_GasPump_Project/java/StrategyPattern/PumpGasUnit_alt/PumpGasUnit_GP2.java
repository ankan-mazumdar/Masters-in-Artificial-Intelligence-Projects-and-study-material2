package StrategyPattern.PumpGasUnit_alt;

import PlatformData.DS;
import PlatformData.DS2;

/*
    GasPump2 PumpGasUnit action responsible for pumping a liter of gas
 */
public class PumpGasUnit_GP2 extends PumpGasUnit {

    public PumpGasUnit_GP2(DS data) {
        super(data);
    }

    /*
        Read and update the appropriate data structure attributes that correspond to
        pumping a liter of gas
     */
    @Override
    public void pumpGasUnit() {
        DS2 d = (DS2) data;

        /*
            Call the subroutine that ACTUALLY pumps gas here
            Now increment the appropriate data values
        */
        d.Set_G(d.Get_G()+1);
        d.Set_total(d.Get_price()*d.Get_G());
    }
}
