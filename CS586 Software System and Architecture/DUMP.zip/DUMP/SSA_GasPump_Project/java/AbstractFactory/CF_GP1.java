package AbstractFactory;

import PlatformData.DS;
import PlatformData.DS1;
import StrategyPattern.CancelMsg.CancelMsg;
import StrategyPattern.CancelMsg.CancelMsg_GP1;
import StrategyPattern.DisplayMenu.DisplayMenu;
import StrategyPattern.DisplayMenu.DisplayMenu_GP1;
import StrategyPattern.GasPumpedMsg.GasPumpedMsg;
import StrategyPattern.GasPumpedMsg.GasPumpedMsg_GP1;
import StrategyPattern.PayMsg.PayMsg;
import StrategyPattern.PayMsg.PayMsg_GP1;
import StrategyPattern.PrintReceipt.PrintReceipt;
import StrategyPattern.PrintReceipt.PrintReceipt_GP1;
import StrategyPattern.PumpGasUnit_alt.PumpGasUnit;
import StrategyPattern.PumpGasUnit_alt.PumpGasUnit_GP1;
import StrategyPattern.RejectMsg.RejectMsg;
import StrategyPattern.RejectMsg.RejectMsg_GP1;
import StrategyPattern.ReturnCash.ReturnCash;
import StrategyPattern.ReturnCash.ReturnCash_GP1;
import StrategyPattern.SetInitialValues.SetInitialValues;
import StrategyPattern.SetInitialValues.SetInitialValues_GP1;
import StrategyPattern.SetPrice_alt.SetPrice;
import StrategyPattern.SetPrice_alt.SetPrice_GP1;
import StrategyPattern.StoreCash.StoreCash;
import StrategyPattern.StoreCash.StoreCash_GP1;
import StrategyPattern.StorePrices.StoreData;
import StrategyPattern.StorePrices.StoreData_GP1;
import StrategyPattern.SetPayType.SetPayType;
import StrategyPattern.SetPayType.SetPayType_GP1;
import StrategyPattern.EjectCard.Ejectcard;
import StrategyPattern.EjectCard.Ejectcard_GP1;
/*
    *******************************Abstract Factory Pattern*************************
    ********************************GasPump1****************************************
    This class is the factory that produces the necessary driver objects for GasPump1
    Instantiates the proper action strategies with the shared data structure
    OutputProcessor object will be instantiated with an object of this class when it needs to
    display output for GasPump1. Output processor will call the methods provided by this class in order to bind
    GasPump1 specific actions.
 */
public class CF_GP1 extends AbstractFactory {
    private DS data;

    public CF_GP1() {
        // Create 1 data structure whose reference is to be passed to all classes that need it
        this.data  = new DS1();
    }

    /*
        Returns the shared data structure that has been instantiated in the constructor
        Appropriate for GasPump1
     */
    @Override
    public DS getDataObj() {
        return this.data;
    }

    /*
        Returns the CancelMsg class that displays the appropriate cancel message action for GasPump1
     */
    @Override
    public CancelMsg getCancelMsg() {
        return new CancelMsg_GP1();
    }

    /*
        Returns the DisplayMenu class that performs the appropriate action for displaying the menu prompt
        for GasPump1.
        The DisplayMenu class is returned already instantiated with the shared data structure it needs
        to read data from.
     */
    @Override
    public DisplayMenu getDisplayMenu() {
        return new DisplayMenu_GP1(this.data);
    }

    /*
        Returns the GasPumpedMsg class that performs the appropriate action for displaying the message that informs
        the user that a unit of gas has been pumped using GasPump1
        The GasPumpedMsg class is returned already instantiated with the shared data structure it needs
        to read data from.
     */
    @Override
    public GasPumpedMsg getGasPumpedMsg() {
        return new GasPumpedMsg_GP1(this.data);
    }
    
    /*
        Returns the getSetPrice class that performs the appropriate action for displaying the message that informs
        the user that a unit of gas has been pumped using GasPump1
        The GasPumpedMsg class is returned already instantiated with the shared data structure it needs
        to read data from.
     */
    @Override
    public SetPrice getSetPrice() {
        return new SetPrice_GP1(data);
    }
    /*
        Returns the Payment prompt message action appropriate for GasPump1
     */
    @Override
    public PayMsg getPayMsg() {
        return new PayMsg_GP1();
    }

    /*
        Returns the PrintReceipt class which is responsible for printing the GasPump1 specific receipt
        The PrintReceipt class returned is already instantiated with the shared data structure it needs
     */
    @Override
    public PrintReceipt getPrintReceipt() {
        return new PrintReceipt_GP1(this.data);
    }

    /*
        Returns the PumpGasUnit class which is responsible to "pumping" a unit of gas for GasPump1
        The PumpGasUnit class returned is already instantiated with the shared data structure it needs
     */
    @Override
    public PumpGasUnit getPumpGasUnit() {
        return new PumpGasUnit_GP1(this.data);
    }


    /*
        Returns the RejectMsg class that displays the appropriate credit card rejection message for GasPump1
     */
    @Override
    public RejectMsg getRejectMsg() {
        return new RejectMsg_GP1();
    }

    /*
        Returns the ReturnCash action object 
     */
    @Override
    public ReturnCash getReturnCash() {
        return new ReturnCash_GP1(data);
    }

    /*
        Returns the SetInitialValues class which provides the appropriate action for initializing
        the shared data structure with GasPump1 specific attributes before a gas unit is pumped.
        The returned class is already instantiated with the shared data structure that it needs.
     */
    @Override
    public SetInitialValues getSetInitialValues() {
        return new SetInitialValues_GP1(this.data);
    }

    /*
        Returns the StoreCash action object appropriate for GasPump1
        GasPump1 does not support cash as payment,
        and so this action strategy method will have an empty body for GasPump1
     */
    @Override
    public StoreCash getStoreCash() {
        return new StoreCash_GP1(data);
    }

    /*
        Returns the StoreData action strategy class appropriate for storing needed input data in the
        shared data structure for GasPump1.
        The returned class is already instantiated with the appropriate shared data structure that it needs.
     */
    @Override
    public StoreData getStoreData() {
        return new StoreData_GP1(this.data);
    }
    
    /*
        Returns the SetPayType action strategy class that sets the payment type to 0 for cash 
        and 1 for credit card
     */
    @Override
    public SetPayType getSetPayType() {
        return new SetPayType_GP1(this.data);
    }
    
    /*
        Returns the Ejectcard action strategy class.
     */
    @Override
    public Ejectcard getEjectcard() {
        return new Ejectcard_GP1();
    }
}
