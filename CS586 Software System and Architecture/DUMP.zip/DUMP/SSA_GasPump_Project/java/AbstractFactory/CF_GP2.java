package AbstractFactory;

import PlatformData.DS;
import PlatformData.DS2;
import StrategyPattern.CancelMsg.CancelMsg;
import StrategyPattern.CancelMsg.CancelMsg_GP2;
import StrategyPattern.DisplayMenu.DisplayMenu;
import StrategyPattern.DisplayMenu.DisplayMenu_GP2;
import StrategyPattern.GasPumpedMsg.GasPumpedMsg;
import StrategyPattern.GasPumpedMsg.GasPumpedMsg_GP2;
import StrategyPattern.PayMsg.PayMsg;
import StrategyPattern.PayMsg.PayMsg_GP2;
import StrategyPattern.PrintReceipt.PrintReceipt;
import StrategyPattern.PrintReceipt.PrintReceipt_GP2;
import StrategyPattern.PumpGasUnit_alt.PumpGasUnit;
import StrategyPattern.PumpGasUnit_alt.PumpGasUnit_GP2;
import StrategyPattern.RejectMsg.RejectMsg;
import StrategyPattern.RejectMsg.RejectMsg_GP2;
import StrategyPattern.ReturnCash.ReturnCash;
import StrategyPattern.ReturnCash.ReturnCash_GP2;
import StrategyPattern.SetInitialValues.SetInitialValues;
import StrategyPattern.SetInitialValues.SetInitialValues_GP2;
import StrategyPattern.SetPrice_alt.SetPrice;
import StrategyPattern.SetPrice_alt.SetPrice_GP2;
import StrategyPattern.StoreCash.StoreCash;
import StrategyPattern.StoreCash.StoreCash_GP2;
import StrategyPattern.StorePrices.StoreData;
import StrategyPattern.StorePrices.StoreData_GP2;
import StrategyPattern.SetPayType.SetPayType;
import StrategyPattern.SetPayType.SetPayType_GP2;
import StrategyPattern.EjectCard.Ejectcard;
import StrategyPattern.EjectCard.Ejectcard_GP2;
/*
    
    *******************************Abstract Factory Pattern*************************
    ********************************GasPump2****************************************
    This class is the factory that produces the necessary driver objects for GasPump2
    Instantiates the proper action strategies with the shared data structure
    OutputProcessor object will be instantiated with an object of this class when it needs to
    display output for GasPump2. Output processor will call the methods provided by this class in order to bind
    GasPump2 specific actions.
*/
public class CF_GP2 extends AbstractFactory {
    private DS data;
    public CF_GP2() {
        // Create 1 data structure whose reference is to be passed to all classes that need it
        data  = new DS2();

    }
    /*
        Returns the shared data structure that has been instantiated in the constructor
        Appropriate for GasPump2
     */
    @Override
    public DS getDataObj() {
        return this.data;
    }

    /*
        Returns the CancelMsg class that provides the appropriate cancel message action for GasPump2
     */
    @Override
    public CancelMsg getCancelMsg() {
        return new CancelMsg_GP2();
    }

    /*
        Returns the DisplayMenu class that performs the appropriate action for displaying the menu prompt
        for GasPump2.
        The DisplayMenu class is returned already instantiated with the shared data structure it needs
        to read data from.
     */
    @Override
    public DisplayMenu getDisplayMenu() {
        return new DisplayMenu_GP2(this.data);
    }

    /*
        Returns the GasPumpedMsg class that performs the appropriate action for displaying the message that informs
        the user that a unit of gas has been pumped using GasPump2
        The GasPumpedMsg class is returned already instantiated with the shared data structure it needs
        to read data from.
     */
    @Override
    public GasPumpedMsg getGasPumpedMsg() {
        return new GasPumpedMsg_GP2(this.data);
    }

    /*
        Returns the Payment prompt message action appropriate for GasPump2
     */
    @Override
    public PayMsg getPayMsg() {
        return new PayMsg_GP2();
    }

    /*
        Returns the PrintReceipt class which is responsible for printing the GasPump2 specific receipt
        The PrintReceipt class returned is already instantiated with the shared data structure it needs
     */
    @Override
    public PrintReceipt getPrintReceipt() {
        return new PrintReceipt_GP2(this.data);
    }

    /*
        Returns the PumpGasUnit class which is responsible to "pumping" a unit of gas for GasPump2
        The PumpGasUnit class returned is already instantiated with the shared data structure it needs
     */
    @Override
    public PumpGasUnit getPumpGasUnit() {
        return new PumpGasUnit_GP2(this.data);
    }

    /*
        Returns the EjectCard action object appropriate for GasPump2
        
     */
    @Override
    public Ejectcard getEjectcard() {
        return new Ejectcard_GP2();
    }
    
    /*
        Returns the ReturnCash action object appropriate for GasPump2
        The returned ReturnCash object will already be instantiated with the shared data structure
        that it needs to read and manipulate.
     */
    @Override
    public ReturnCash getReturnCash() {
        return new ReturnCash_GP2(data);
    }
    
    /*
        Returns the SetPayType action strategy class that sets the payment type to 0 for cash 
        GasPump2 does not support payment by credit card.
     */
    @Override
    public SetPayType getSetPayType() {
        return new SetPayType_GP2(data);
    }

    /*
        Returns the SetInitialValues class which provides the appropriate action for initializing
        the shared data structure with GasPump2 specific attributes before a gas unit is pumped.
        The returned class is already instantiated with the shared data structure that it needs.
    */
    @Override
    public SetInitialValues getSetInitialValues() {
        return new SetInitialValues_GP2(this.data);
    }

    /*
        Returns the SetPrice class that is responsible for setting the price of gasoline according to
        specifications of GasPump2 requirements.
        The returned class is already instantiated with the shared data structure that it needs.
    */
    @Override
    public SetPrice getSetPrice() {
        return new SetPrice_GP2(this.data);
    }

    /*
        Returns the StoreCash class which provides the appropriate action for storing cash
        on GasPump2.
        The returned StoreCash object is already instantiated with the necessary data structure
        that it needs to write into.
     */
    @Override
    public StoreCash getStoreCash() {
        return new StoreCash_GP2(this.data);
    }

    /*
        Returns the StoreData class which provides the appropriate action for storing the gas
        price data for GasPump2
        The returned StoreData object is already instantiated with the shared data structure it needs to
        write into.
     */
    @Override
    public StoreData getStoreData() {
        return new StoreData_GP2(this.data);
    }

    /*
        GasPump2 does not require this action. It is only a blank implementation.
     */
    @Override
    public RejectMsg getRejectMsg() {
        return new RejectMsg_GP2();
    }
}
