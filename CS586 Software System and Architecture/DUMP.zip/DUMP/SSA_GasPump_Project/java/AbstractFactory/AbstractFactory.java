package AbstractFactory;

import PlatformData.DS;
import StrategyPattern.CancelMsg.CancelMsg;
import StrategyPattern.DisplayMenu.DisplayMenu;
import StrategyPattern.EjectCard.Ejectcard;
import StrategyPattern.GasPumpedMsg.GasPumpedMsg;
import StrategyPattern.PayMsg.PayMsg;
import StrategyPattern.PrintReceipt.PrintReceipt;
import StrategyPattern.PumpGasUnit_alt.PumpGasUnit;
import StrategyPattern.RejectMsg.RejectMsg;
import StrategyPattern.ReturnCash.ReturnCash;
import StrategyPattern.SetInitialValues.SetInitialValues;
import StrategyPattern.SetPrice_alt.SetPrice;
import StrategyPattern.StoreCash.StoreCash;
import StrategyPattern.StorePrices.StoreData;
import StrategyPattern.SetPayType.SetPayType;


/*
    *******************************Abstract Factory Pattern*************************
    
    This class groups all ConcreteFactory classes under 1 abstract superclass
    It defines the methods that return the GasPump specific action components which
    all ConcreteFactories need to implement

 */
public abstract class AbstractFactory {

    public abstract DS getDataObj();

    public abstract CancelMsg getCancelMsg();

    public abstract DisplayMenu getDisplayMenu();

    public abstract GasPumpedMsg getGasPumpedMsg();

    public abstract PayMsg getPayMsg();

    public abstract PrintReceipt getPrintReceipt();

    public abstract PumpGasUnit getPumpGasUnit();

    public abstract RejectMsg getRejectMsg();

    public abstract ReturnCash getReturnCash();

    public abstract SetInitialValues getSetInitialValues();

    public abstract SetPrice getSetPrice();

    public abstract StoreCash getStoreCash();

    public abstract StoreData getStoreData();

    public abstract SetPayType getSetPayType();

    public abstract Ejectcard getEjectcard();

}