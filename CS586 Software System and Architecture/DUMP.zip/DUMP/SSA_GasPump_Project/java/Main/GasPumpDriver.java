package Main;

import AbstractFactory.*;
import GasPump.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

//This is the Driver class
public class GasPumpDriver {
    public static void main(String[] args) {
        BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Select type of GasPump: ");
        System.out.println("1. GasPump1");
        System.out.println("2. GasPump2");
        System.out.print("> ");

        int pump_type;
        String input = "initial";
        try {
            pump_type = Integer.parseInt(scan.readLine());
            switch (pump_type) {
                case 1: {
                    CF_GP1 cf1 = new CF_GP1();
                    GasPump1 gp1 = new GasPump1(cf1);
                    while (!input.equals("q")) {
                        gp1.printOperations();
                        input = scan.readLine();
                        switch (input) {
                            case "0": { // Activate
                                System.out.println(">Activate<");
                                int a;
                                System.out.println("Enter  the value of parameter a to set price of gas per liter: ");
                                try {
                                    a = Integer.parseInt(scan.readLine());
                                    gp1.Activate(a);
                                } catch (NumberFormatException e) {
                                    System.out.println("Type mismatch. Price should be an integer.");
                                }
                                break;
                            }
                            case "1": { // Start
                                System.out.println(">Start<");
                                gp1.Start();
                                break;
                            }
                            case "2": { // PayCredit
                                System.out.println(">PayCredit<");
                                gp1.PayCredit();
                                break;
                            }
                            case "3": { // Approve
                                System.out.println(">Approved<");
                                gp1.Approve();
                                break;
                            }
                            case "4": { // Reject
                                System.out.println(">Reject<");
                                gp1.Reject();
                                break;
                            }
                            case "5": { // PayCash
                                System.out.println(">Pay Cash<");
                                System.out.println("Insert cash (enter $ amount): ");
                                int cash;
                                cash = Integer.parseInt(scan.readLine());
                                gp1.PayCash(cash);
                                break;
                            }
                            case "6": { // Cancel
                                System.out.println(">Cancel<");
                                gp1.Cancel();
                                break;
                            }
                            case "7": { // StartPump
                                System.out.println(">StartPump<");
                                gp1.StartPump();
                                break;
                            }
                            case "8": { // Pump
                                System.out.println(">Pump<");
                                gp1.Pump();
                                break;
                            }
                            case "9": { // StopPump
                                System.out.println(">StopPump<");
                                System.out.println("Pumping stopped");
                                gp1.StopPump();
                                break;
                            }
                            case "q": { // Quit
                                break;
                            }
                            case "s": { // Check State
                                gp1.check();
                                break;
                            }
                            default: { // Anything else: unknown / unsupported operation
                                System.out.println("Unknown operation: '" + input + "'");
                                System.out.println("Please select a valid operation");
                                break;
                            }
                        }
                    } // End while loop
                    System.out.println("Quitting ...");
                    break;
                } // End pump_type = 1 case
                case 2: {
                    //GasPump 2
                    CF_GP2 cf2 = new CF_GP2();
                    GasPump2 gp2 = new GasPump2(cf2);
                    while (!input.equals("q")) {
                        gp2.printOperations();
                        input = scan.readLine();
                        switch (input) {
                            case "0": { // Activate
                                System.out.println(">Activate<");
                                float a, b, c;
                                System.out.println("Enter the price parameter a: ");
                                try {
                                    a = Float.parseFloat(scan.readLine());
                                    System.out.println("Enter the price parameter b: ");
                                    b = Float.parseFloat(scan.readLine());
                                    System.out.println("Enter the price parameter c: ");
                                    c = Float.parseFloat(scan.readLine());
                                    gp2.Activate(a, b, c);
                                } catch (NumberFormatException e) {
                                    System.out.println("Type mismatch. Price needs to be a decimal");
                                }
                                break;
                            }
                            case "1": { // Start
                                System.out.println(">Start<");
                                gp2.Start();
                                break;
                            }
                            case "2": { // PayCash
                                System.out.println(">PayCash<");
                                System.out.println("Insert cash (enter $ amount): ");
                                try {
                                    int cash = Integer.parseInt(scan.readLine());
                                    gp2.PayCash(cash);
                                } catch (NumberFormatException e) {
                                    System.out.println("Type mismatch. Dollar amount must be a floating point decimal number");
                                }
                                break;
                            }
                            case "3": { // Regular
                                System.out.println(">Regular<");
                                gp2.Regular();
                                break;
                            }
                            case "4": { // Premium
                                System.out.println(">Premium<");
                                gp2.Premium();
                                break;
                            }
                            case "5": { // Diesel
                                System.out.println(">Diesel<");
                                gp2.Diesel();
                                break;
                            }
                            case "6": { // Cancel
                                System.out.println(">Cancel<");
                                gp2.Cancel();
                                break;
                            }
                            case "7": { // Start Pump
                                System.out.println(">StartPump<");
                                gp2.StartPump();
                                break;
                            }
                            case "8": { // PumpGallon
                                System.out.println(">PumpGallon<");
                                gp2.PumpGallon();
                                break;
                            }
                            case "9": { // Stop
                                System.out.println(">Stop<");
                                System.out.println("Pumping stopped");
                                gp2.Stop();
                                break;
                            }
                            case "p": { // PrintReceipt
                                System.out.println(">PrintReceipt<");
                                gp2.Receipt();
                                break;
                            }
                            case "n": { // NoReceipt
                                System.out.println(">NoReceipt<");
                                gp2.NoReceipt();
                                break;
                            }
                            case "s": { // Check State and Values
                                gp2.check();
                                break;
                            }
                            case "q": { // Quit
                                break;
                            }
                            default: { // Anything else: unknown / unsupported operation
                                System.out.println("Unknown operation: '" + input + "'");
                                System.out.println("Please enter a valid operation");
                                break;
                            }
                        }
                    } // End while loop
                    System.out.println("Quitting ...");
                    break;
                } // end pump_type = 2 case
                default: {
                    System.out.println("Unknown GasPump selection. Terminating ...");
                    System.exit(1);
                }

            }
        } catch (IOException ioe) {
            System.out.println("Some error has been ocurred. Terminating ...");
            System.exit(1);
        }
    }
}