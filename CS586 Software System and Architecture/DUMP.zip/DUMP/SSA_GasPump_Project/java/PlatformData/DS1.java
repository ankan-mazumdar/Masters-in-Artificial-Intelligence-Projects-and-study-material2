package PlatformData;

// DS1 is the storage for GasPump1
public class DS1 extends DS {
    int price;
    int w;
    int cash;
    int L;
    int total;

    // temporary variables
    int temp_a;
    int temp_cash;

    //get set for price
    public int Get_price(){
        return price;
    }
    public void Set_price(int value){
        price = value;
    }
    
    //get set for w
    public int Get_w(){
        return w;
    }
    public void Set_w(int value){
        w = value;
    }
    
    //get set for cash
    public int Get_cash(){
        return cash;
    }
    public void Set_cash(int value){
        cash = value;
    }
    
    //get set for L
    public int Get_L(){
        return L;
    }
    public void Set_L(int value){
        L = value;
    }
    
    //get set for total
    public int Get_total(){
        return total;
    }
    public void Set_total(int value){
        total = value;
    }
    
    //get set for temp_a
    public int Get_temp_a(){
        return temp_a;
    }
    public void Set_temp_a(int value){
        temp_a = value;
    }
    
    //get set for temp_cash
    public int Get_temp_cash(){
        return temp_cash;
    }
    public void Set_temp_cash(int value){
        temp_cash = value;
    }
}
