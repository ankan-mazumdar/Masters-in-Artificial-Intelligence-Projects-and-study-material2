package PlatformData;

/*
 This class acts as a data store for all the data used in both GapPumps.
 This abstract class is further inherited by DS1(for GasPump1 data) and DS2(for GasPump1 data)
 */
public abstract class DS {
}
