package PlatformData;

// DS2 is the storage for GasPump2
public class DS2 extends DS {
    float Rprice;
    float Pprice;
    float Dprice;
    float price;
    int w;
    int cash;
    float total;
    int G;
    // temporary variables
    float temp_a;
    float temp_b;
    float temp_c;
    int temp_cash; 
    
    //get set for Dprice
    public float Get_Dprice(){
        return Dprice;
    }
    public void Set_Dprice(float value){
        Dprice = value;
    }

    //get set for Pprice
    public float Get_Pprice(){
        return Pprice;
    }
    public void Set_Pprice(float value){
        Pprice = value;
    }

    //get set for Rprice
    public float Get_Rprice(){
        return Rprice;
    }
    public void Set_Rprice(float value){
        Rprice = value;
    }

    //get set for price
    public float Get_price(){
        return price;
    }
    public void Set_price(float value){
        price = value;
    }

    //get set for w
    public int Get_w(){
        return w;
    }
    public void Set_w(int value){
        w = value;
    }

    //get set for cash
    public int Get_cash(){
        return cash;
    }
    public void Set_cash(int value){
        cash = value;
    }

    //get set for total
    public float Get_total(){
        return total;
    }
    public void Set_total(float value){
        total = value;
    }

    //get set for G
    public int Get_G(){
        return G;
    }
    public void Set_G(int value){
        G = value;
    }
    
    //get set for temp_c
    public float Get_temp_c(){
        return temp_c;
    }
    public void Set_temp_c(float value){
        temp_c = value;
    }


    //get set for temp_b
    public float Get_temp_b(){
        return temp_b;
    }
    public void Set_temp_b(float value){
        temp_b = value;
    }

    //get set for temp_a
    public float Get_temp_a(){
        return temp_a;
    }
    public void Set_temp_a(float value){
        temp_a = value;
    }

    //get set for temp_cash
    public int Get_temp_cash(){
        return temp_cash;
    }
    public void Set_temp_cash(int value){
        temp_cash = value;
    }
    
}
