package Model.EFSM;

/*
    *******************************State Pattern**********************************
    State S1 in the EFSM model
 */
class S1 extends State {

    S1(MDAEFSM model) {
        super(model);
    }

    /*
        credit: t=1
            Transition to State S2
            No meta-action called
        cash:   t=2
            Transition to State S3
            Call StoreCash(), DisplayMenu() and SetPayType(int t) meta-actions
     */
    @Override
    void payType(int t) {
        if ((t == 1) && (model.s == model.LS[1])) {
            model.ChangeState(2);
        } else if ((t == 0) && (model.s == model.LS[1])) {
            model.ChangeState(3);
            model.getOP().StoreCash();
            model.getOP().DisplayMenu();
            model.getOP().SetPayType(t);
        }
    }
}
