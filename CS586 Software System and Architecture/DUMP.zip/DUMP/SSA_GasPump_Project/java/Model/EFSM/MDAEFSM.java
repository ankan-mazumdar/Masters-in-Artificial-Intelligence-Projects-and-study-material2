package Model.EFSM;

import Model.OutputProcessor.OutputProcessor;

/*
    This class is the MDA-EFSM class in the De-centralized State design pattern
    State classes are responsible for performing
        1) Actions
        2) State transitions
 */

public class MDAEFSM {
    protected State s;
    protected State[] LS;
    private OutputProcessor op;

    public MDAEFSM() {
        // list of states in the EFSM
        LS = new State[8];

        // instantiate each state, passing in a reference to this VM class
        LS[7] = new Start(this);
        LS[0] = new S0(this);
        LS[1] = new S1(this);
        LS[2] = new S2(this);
        LS[3] = new S3(this);
        LS[4] = new S4(this);
        LS[5] = new S5(this);
        LS[6] = new S6(this);

        s = LS[7]; // Initially in the Start State
    }

    public OutputProcessor getOP() {
        return op;
    }

    public void setOP(OutputProcessor op) {
        this.op = op;
    }

    public void activate() {
        s.activate();
    }

    public void start() {
        s.start();
    }

    public void payType(int t) {
        s.payType(t);
    }

    public void approve() {
        s.approve();
    }

    public void reject() {
        s.reject();
    }

    public void cancel() {
        s.cancel();
    }

    public void selectGas(int g) {
        s.selectGas(g);
    }

    public void startPump() {
        s.startPump();
    }

    public void pump() {
        s.pump();
    }

    public void stopPump() {
        s.stopPump();
    }

    public void receipt() {
        s.receipt();
    }

    public void noReceipt() {
        s.noReceipt();
    }
    
    /*
     Continue function only changes the state
     */
    public void Continue(){
        s.Continue();
    }
    
    /*
     ChangeState() functions are called from differnt stages for state transitions.
     State is set to the state passed as argument.
     */
    public void ChangeState(int stateID){
     s = LS[stateID];
    }
    
    /*
     This function can be used to chcek the state of machine at any point of time.
     Not required for our implementation.
     */
    public int CheckState(){
        for (int index = 0; index < LS.length; index++) {
            if(s == LS[index]){
                return index;
            }              
        }
        return 100;
    }


}
