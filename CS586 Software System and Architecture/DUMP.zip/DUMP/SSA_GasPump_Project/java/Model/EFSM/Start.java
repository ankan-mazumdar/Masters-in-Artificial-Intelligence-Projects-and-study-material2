package Model.EFSM;

/*
    Initial State in the EFSM model
 */
class Start extends State {

    Start(MDAEFSM model) {
        super(model);
    }

    /*
        *******************************State Pattern**********************************
        Transition to State S0 and call the StoreData() meta-action
     */
    @Override
    void activate() {
        if (model.s == model.LS[7]) {
            model.ChangeState(0);
            model.getOP().StoreData();
        }
    }
}
