package Model.EFSM;

/*
    State S4 in the EFSM model
 */
class S4 extends State {

    S4(MDAEFSM model) {
        super(model);
    }

    /*
        *******************************State Pattern**********************************
        Transition to State S2 and call SetInitialValues() and ReadyMsg() meta-actions
     */
    @Override
    void startPump() {
        if (model.s == model.LS[4]) {
            model.ChangeState(5);
            model.getOP().SetInitialValues();
           // System.out.println("You can start pumping gas now - ");
        }
    }
}
