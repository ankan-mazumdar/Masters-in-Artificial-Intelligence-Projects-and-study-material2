package Model.EFSM;

/*
    State S3 in the EFSM model
 */
class S3 extends State {

    S3(MDAEFSM model) {
        super(model);
    }

    /*
        *******************************State Pattern**********************************
        Transition to State S4 and call SetPrice() meta-action
     */
    @Override
    void selectGas(int g) {
       
        model.getOP().SetPrice(g);
    }
    
    @Override
    public void Continue(){
        if(model.s == model.LS[3]){
            model.ChangeState(4);
        }
    }
    

    /*
        Transition to State S0 and call CancelMsg() and ReturnCash() meta-actions
     */
    @Override
    void cancel() {
        if (model.s == model.LS[3]) {
            model.ChangeState(0);
            model.getOP().CancelMsg();
        }
    }
}
