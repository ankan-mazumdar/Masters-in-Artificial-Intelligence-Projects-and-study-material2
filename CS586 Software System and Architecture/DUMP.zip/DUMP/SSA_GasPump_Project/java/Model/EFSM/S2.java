package Model.EFSM;

/*
    State S2 in the EFSM model
 */
class S2 extends State {

    S2(MDAEFSM model) {
        super(model);
    }

    /*
        *******************************State Pattern**********************************
        Transition to State S3 and call DisplayMenu() meta-action
     */
    @Override
    void approve() {
        if (model.s == model.LS[2]) {
            model.ChangeState(3);
            model.getOP().DisplayMenu();
            model.getOP().SetPayType(1);
            model.getOP().EjectCard();
        }
    }

    /*
        Transition to State S0 and call RejectMsg() meta-action
     */
    @Override
    void reject() {
        if (model.s == model.LS[2]) {
            model.ChangeState(0);
            model.getOP().RejectMsg();
            model.getOP().EjectCard();
        }
    }
}
