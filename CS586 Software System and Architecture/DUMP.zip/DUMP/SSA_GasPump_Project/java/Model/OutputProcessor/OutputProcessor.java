package Model.OutputProcessor;

import AbstractFactory.AbstractFactory;
import StrategyPattern.CancelMsg.CancelMsg;
import StrategyPattern.DisplayMenu.DisplayMenu;
import StrategyPattern.GasPumpedMsg.GasPumpedMsg;
import StrategyPattern.PayMsg.PayMsg;
import StrategyPattern.PrintReceipt.PrintReceipt;
import StrategyPattern.PumpGasUnit_alt.PumpGasUnit;
import StrategyPattern.RejectMsg.RejectMsg;
import StrategyPattern.ReturnCash.ReturnCash;
import StrategyPattern.SetInitialValues.SetInitialValues;
import StrategyPattern.SetPayType.SetPayType;
import StrategyPattern.SetPrice_alt.SetPrice;
import StrategyPattern.StoreCash.StoreCash;
import StrategyPattern.StorePrices.StoreData;
import StrategyPattern.EjectCard.*;

/*
    This class is the general output processor for the gas pump system.
    It must be initialized with the proper action implementations for the specific
    gas pump that is desired. This is done thorough the Abstract Factory design pattern.

    Each meta-action in this class calls the platform specific implementation of the action

    This class acts as the "Client" class in the strategy design pattern
 */
public class OutputProcessor {
    private CancelMsg cancelMsg;
    private DisplayMenu displayMenu;
    private GasPumpedMsg gasPumpedMsg;
    private PayMsg payMsg;
    private PrintReceipt printReceipt;
    private PumpGasUnit pumpGasUnit;
    private RejectMsg rejectMsg;
    private ReturnCash returnCash;
    private SetInitialValues setInitialValues;
    private SetPrice setPrice;
    private StoreCash storeCash;
    private StoreData storeData;
    private SetPayType setPayType;
    private Ejectcard ejectcard;

    public OutputProcessor(AbstractFactory af) {
        this.cancelMsg = af.getCancelMsg();
        this.displayMenu = af.getDisplayMenu();
        this.gasPumpedMsg = af.getGasPumpedMsg();
        this.payMsg = af.getPayMsg();
        this.printReceipt = af.getPrintReceipt();
        this.pumpGasUnit = af.getPumpGasUnit();
        this.rejectMsg = af.getRejectMsg();
        this.returnCash = af.getReturnCash();
        this.setInitialValues = af.getSetInitialValues();
        this.setPrice = af.getSetPrice();
        this.storeCash = af.getStoreCash();
        this.storeData = af.getStoreData();
        this.setPayType = af.getSetPayType();
        this.ejectcard = af.getEjectcard();
    }

    /*
     *  Meta-actions (implemented using Strategy pattern)
     */

    public void CancelMsg() {
        this.cancelMsg.cancelMsg();
    }

    public void DisplayMenu() {
        this.displayMenu.displayMenu();
    }

    public void GasPumpedMsg() {
        this.gasPumpedMsg.gasPumpedMsg();
    }

    public void PayMsg() {
        this.payMsg.payMsg();
    }

    public void PrintReceipt() {
        this.printReceipt.printReceipt();
    }

    public void PumpGasUnit() {
        this.pumpGasUnit.pumpGasUnit();
    }

    public void RejectMsg() {
        this.rejectMsg.rejectMsg();
    }

    public void ReturnCash() {
        this.returnCash.returnCash();
    }

    public void SetInitialValues() {
        this.setInitialValues.setInitialValues();
    }

    public void SetPrice(int g) {
        this.setPrice.setPrice(g);
    }

    public void StoreCash() {
        this.storeCash.storeCash();
    }

    public void StoreData() {
        this.storeData.storeData();
    }

    public void SetPayType(int t) {
        this.setPayType.setPayType(t);
    }

    public void EjectCard() {
        this.ejectcard.ejectCard();
    }

}
